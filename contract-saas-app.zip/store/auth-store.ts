import { create } from "zustand"
import { persist } from "zustand/middleware"

export interface Agency {
  id: string
  name: string
  email: string
  logo?: string
  phone?: string
  address?: string
  website?: string
  description?: string
  createdAt: string
}

interface AuthStore {
  isAuthenticated: boolean
  agency: Agency | null

  // Actions
  login: (agency: Agency) => void
  logout: () => void
  updateAgency: (updates: Partial<Agency>) => void
  register: (agencyData: Omit<Agency, "id" | "createdAt">) => void
}

export const useAuthStore = create<AuthStore>()(
  persist(
    (set, get) => ({
      isAuthenticated: false,
      agency: null,

      login: (agency) =>
        set({
          isAuthenticated: true,
          agency,
        }),

      logout: () =>
        set({
          isAuthenticated: false,
          agency: null,
        }),

      updateAgency: (updates) =>
        set((state) => ({
          agency: state.agency ? { ...state.agency, ...updates } : null,
        })),

      register: (agencyData) => {
        const newAgency: Agency = {
          ...agencyData,
          id: Date.now().toString(),
          createdAt: new Date().toISOString(),
        }
        set({
          isAuthenticated: true,
          agency: newAgency,
        })
      },
    }),
    {
      name: "auth-storage",
    },
  ),
)
