import { create } from "zustand"
import { persist } from "zustand/middleware"

export interface CustomClause {
  title: string
  description: string
}

export interface ContractData {
  id?: string
  type: "client" | "hiring" | ""
  clientName: string
  clientEmail: string
  agencyName: string
  agencyEmail: string
  projectTitle: string
  projectDescription: string
  scope: string[]
  paymentAmount: number
  paymentTerms: string
  startDate: string
  endDate: string
  clauses: CustomClause[] // Changed from string[] to CustomClause[]
  status: "draft" | "review" | "signed" | "completed"
  createdAt: string
  updatedAt: string
  agencySignature?: string
  agencySignedAt?: string
  clientSignature?: string
  clientSignedAt?: string
  shareableLink?: string
}

interface ContractStore {
  currentContract: ContractData
  contracts: ContractData[]
  currentStep: number
  isPreviewMode: boolean

  // Actions
  updateContract: (data: Partial<ContractData>) => void
  setCurrentStep: (step: number) => void
  togglePreviewMode: () => void
  saveContract: () => void
  loadContract: (id: string) => void
  deleteContract: (id: string) => void
  duplicateContract: (id: string) => void
  resetContract: () => void
  signAsAgency: (signature: string) => void
  signAsClient: (signature: string) => void
  generateShareableLink: () => string
}

// Fix the initial contract to ensure proper structure
const initialContract: ContractData = {
  type: "",
  clientName: "",
  clientEmail: "",
  agencyName: "",
  agencyEmail: "",
  projectTitle: "",
  projectDescription: "",
  scope: [],
  paymentAmount: 0,
  paymentTerms: "",
  startDate: "",
  endDate: "",
  clauses: [], // Ensure this is always an array of CustomClause objects
  status: "draft",
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString(),
}

// Add a helper function to ensure clauses are properly structured
const ensureClausesStructure = (clauses: any): CustomClause[] => {
  if (!Array.isArray(clauses)) return []

  return clauses.map((clause) => {
    if (typeof clause === "string") {
      return { title: clause, description: clause }
    }
    if (typeof clause === "object" && clause !== null) {
      return {
        title: clause.title || "Untitled Clause",
        description: clause.description || clause.title || "No description provided",
      }
    }
    return { title: "Invalid Clause", description: "Invalid clause data" }
  })
}

export const useContractStore = create<ContractStore>()(
  persist(
    (set, get) => ({
      currentContract: initialContract,
      contracts: [],
      currentStep: 1,
      isPreviewMode: false,

      updateContract: (data) =>
        set((state) => {
          const updatedData = { ...data }

          // Ensure clauses are properly structured
          if (updatedData.clauses) {
            updatedData.clauses = ensureClausesStructure(updatedData.clauses)
          }

          return {
            currentContract: {
              ...state.currentContract,
              ...updatedData,
              updatedAt: new Date().toISOString(),
            },
          }
        }),

      setCurrentStep: (step) => set({ currentStep: step }),

      togglePreviewMode: () => set((state) => ({ isPreviewMode: !state.isPreviewMode })),

      saveContract: () =>
        set((state) => {
          const contract = {
            ...state.currentContract,
            id: state.currentContract.id || Date.now().toString(),
            updatedAt: new Date().toISOString(),
          }

          const existingIndex = state.contracts.findIndex((c) => c.id === contract.id)

          const updatedContracts =
            existingIndex >= 0
              ? state.contracts.map((c, i) => (i === existingIndex ? contract : c))
              : [...state.contracts, contract]

          return {
            currentContract: contract,
            contracts: updatedContracts,
          }
        }),

      loadContract: (id) =>
        set((state) => {
          const contract = state.contracts.find((c) => c.id === id)
          if (contract) {
            return {
              currentContract: {
                ...contract,
                clauses: ensureClausesStructure(contract.clauses),
              },
            }
          }
          return state
        }),

      deleteContract: (id) =>
        set((state) => ({
          contracts: state.contracts.filter((c) => c.id !== id),
        })),

      duplicateContract: (id) =>
        set((state) => {
          const contract = state.contracts.find((c) => c.id === id)
          if (!contract) return state

          const duplicated = {
            ...contract,
            id: Date.now().toString(),
            projectTitle: `${contract.projectTitle} (Copy)`,
            status: "draft" as const,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
          }

          return {
            contracts: [...state.contracts, duplicated],
          }
        }),

      resetContract: () =>
        set({
          currentContract: initialContract,
          currentStep: 1,
          isPreviewMode: false,
        }),

      signAsAgency: (signature) =>
        set((state) => ({
          currentContract: {
            ...state.currentContract,
            agencySignature: signature,
            agencySignedAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
          },
        })),

      signAsClient: (signature) =>
        set((state) => ({
          currentContract: {
            ...state.currentContract,
            clientSignature: signature,
            clientSignedAt: new Date().toISOString(),
            status: "signed",
            updatedAt: new Date().toISOString(),
          },
        })),

      generateShareableLink: () => {
        const contractId = get().currentContract.id || Date.now().toString()
        const shareableLink = `${window.location.origin}/client/contract/${contractId}`

        set((state) => ({
          currentContract: {
            ...state.currentContract,
            id: contractId,
            shareableLink,
            updatedAt: new Date().toISOString(),
          },
        }))

        return shareableLink
      },
    }),
    {
      name: "contract-storage",
      partialize: (state) => ({
        contracts: state.contracts,
        currentContract: state.currentContract,
      }),
    },
  ),
)
