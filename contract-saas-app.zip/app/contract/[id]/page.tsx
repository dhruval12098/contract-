"use client"

import { motion } from "framer-motion"
import { Download, Send, ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useContractStore } from "@/store/contract-store"
import { ContractPreview } from "@/components/contract-preview"
import Link from "next/link"
import { useParams } from "next/navigation"
import { useEffect } from "react"

export default function ContractViewPage() {
  const params = useParams()
  const contractId = params.id as string
  const { contracts, loadContract, currentContract } = useContractStore()

  useEffect(() => {
    if (contractId && contractId !== "new-contract") {
      loadContract(contractId)
    }
  }, [contractId, loadContract])

  const contract =
    contractId === "new-contract" ? currentContract : contracts.find((c) => c.id === contractId) || currentContract

  const handleDownload = () => {
    window.print()
  }

  const handleSendToClient = () => {
    // Navigate to signing page
    window.open(`/contract/${contractId}/sign`, "_blank")
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="container mx-auto p-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="flex items-center justify-between mb-8"
        >
          <div className="flex items-center gap-4">
            <Button variant="outline" size="sm" asChild className="bg-transparent">
              <Link href="/dashboard">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back to Dashboard
              </Link>
            </Button>
            <div>
              <h1 className="text-2xl font-bold">{contract.projectTitle || "Contract Preview"}</h1>
              <p className="text-muted-foreground">
                {contract.type === "client" ? "Client Contract" : "Hiring Contract"}
              </p>
            </div>
          </div>

          <div className="flex gap-3">
            <Button onClick={handleDownload} variant="outline" className="bg-transparent">
              <Download className="mr-2 h-4 w-4" />
              Download PDF
            </Button>
            <Button onClick={handleSendToClient} className="shadow-md hover:shadow-lg transition-shadow">
              <Send className="mr-2 h-4 w-4" />
              Send for Signing
            </Button>
          </div>
        </motion.div>

        {/* Contract */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="max-w-4xl mx-auto"
        >
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-8">
            <ContractPreview contract={contract} />
          </div>
        </motion.div>
      </div>
    </div>
  )
}
