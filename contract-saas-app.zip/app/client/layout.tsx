import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "../globals.css"

const inter = Inter({
  subsets: ["latin"],
  display: "swap",
})

export const metadata: Metadata = {
  title: "Contract Review & Signing - ContractAI",
  description: "Review and sign your contract securely",
  robots: "noindex, nofollow", // Prevent indexing of client pages
}

export default function ClientLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return children
}
