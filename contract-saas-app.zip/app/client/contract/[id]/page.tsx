"use client"

import type React from "react"
import { motion } from "framer-motion"
import { Upload, PenTool, CheckCircle, Download, FileText, Building, User } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useContractStore } from "@/store/contract-store"
import { useParams } from "next/navigation"
import { useEffect, useState, useRef } from "react"

export default function ClientContractPage() {
  const params = useParams()
  const contractId = params.id as string
  const { contracts, loadContract, signAsClient } = useContractStore()
  const [contract, setContract] = useState<any>(null)
  const [signatureMethod, setSignatureMethod] = useState<"upload" | "draw" | null>(null)
  const [isDrawing, setIsDrawing] = useState(false)
  const [isSigned, setIsSigned] = useState(false)
  const [signerName, setSignerName] = useState("")
  const [signerEmail, setSignerEmail] = useState("")
  const [isLoading, setIsLoading] = useState(true)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    const loadContractData = async () => {
      setIsLoading(true)
      try {
        if (contractId) {
          loadContract(contractId)
          const foundContract = contracts.find((c) => c.id === contractId)
          if (foundContract) {
            // Ensure contract has proper structure
            const safeContract = {
              ...foundContract,
              clauses: Array.isArray(foundContract.clauses) ? foundContract.clauses : [],
              scope: Array.isArray(foundContract.scope) ? foundContract.scope : [],
            }
            setContract(safeContract)
            setSignerName(safeContract.clientName || "")
            setSignerEmail(safeContract.clientEmail || "")
            setIsSigned(!!safeContract.clientSignature)
          }
        }
      } catch (error) {
        console.error("Error loading contract:", error)
      } finally {
        setIsLoading(false)
      }
    }

    loadContractData()
  }, [contractId, contracts, loadContract])

  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement>) => {
    setIsDrawing(true)
    const canvas = canvasRef.current
    if (canvas) {
      const rect = canvas.getBoundingClientRect()
      const ctx = canvas.getContext("2d")
      if (ctx) {
        ctx.strokeStyle = "#000"
        ctx.lineWidth = 2
        ctx.lineCap = "round"
        ctx.beginPath()
        ctx.moveTo(e.clientX - rect.left, e.clientY - rect.top)
      }
    }
  }

  const draw = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return
    const canvas = canvasRef.current
    if (canvas) {
      const rect = canvas.getBoundingClientRect()
      const ctx = canvas.getContext("2d")
      if (ctx) {
        ctx.lineTo(e.clientX - rect.left, e.clientY - rect.top)
        ctx.stroke()
      }
    }
  }

  const stopDrawing = () => {
    setIsDrawing(false)
  }

  const clearSignature = () => {
    const canvas = canvasRef.current
    if (canvas) {
      const ctx = canvas.getContext("2d")
      if (ctx) {
        ctx.clearRect(0, 0, canvas.width, canvas.height)
      }
    }
  }

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (event) => {
        const imageData = event.target?.result as string
        signAsClient(imageData)
        setIsSigned(true)
      }
      reader.readAsDataURL(file)
    }
  }

  const handleSignContract = () => {
    if (signatureMethod === "draw") {
      const canvas = canvasRef.current
      if (canvas) {
        const signatureData = canvas.toDataURL()
        signAsClient(signatureData)
        setIsSigned(true)
      }
    }
  }

  const handleDownload = () => {
    window.print()
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading contract...</p>
        </div>
      </div>
    )
  }

  if (!contract) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
          <h1 className="text-xl font-semibold mb-2">Contract Not Found</h1>
          <p className="text-muted-foreground">The contract you're looking for doesn't exist or has been removed.</p>
        </div>
      </div>
    )
  }

  if (isSigned || contract.clientSignature) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 dark:from-green-950/20 dark:to-blue-950/20 flex items-center justify-center p-6">
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.5 }}
          className="max-w-md w-full"
        >
          <Card className="shadow-xl border-0">
            <CardContent className="text-center py-8">
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
                className="w-20 h-20 bg-green-100 dark:bg-green-900 rounded-full flex items-center justify-center mx-auto mb-6"
              >
                <CheckCircle className="h-10 w-10 text-green-600 dark:text-green-400" />
              </motion.div>
              <h1 className="text-2xl font-bold mb-2">Contract Signed Successfully!</h1>
              <p className="text-muted-foreground mb-6">
                Thank you for signing the contract. Both parties will receive a copy via email.
              </p>
              <div className="space-y-3">
                <Button onClick={handleDownload} className="w-full shadow-md hover:shadow-lg transition-shadow">
                  <Download className="mr-2 h-4 w-4" />
                  Download Signed Contract
                </Button>
                <p className="text-xs text-muted-foreground">Contract ID: {contractId}</p>
              </div>
            </CardContent>
          </Card>

          {/* Branding Footer */}
          <div className="mt-8 text-center">
            <p className="text-xs text-muted-foreground">
              Product by <span className="font-semibold text-primary">Drimin AI</span>
            </p>
          </div>
        </motion.div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <div className="bg-white dark:bg-gray-800 border-b shadow-sm">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
              <FileText className="h-5 w-5 text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-xl font-bold">Contract Review & Signing</h1>
              <p className="text-sm text-muted-foreground">
                {contract.agencyName} • {contract.type === "client" ? "Service Agreement" : "Employment Contract"}
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto p-6">
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Contract Preview */}
          <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.5 }}>
            <Card className="shadow-lg border-0">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="h-5 w-5" />
                  Contract Details
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6 text-sm">
                  {/* Contract Header */}
                  <div className="text-center border-b pb-4">
                    <h2 className="text-lg font-bold uppercase">
                      {contract.type === "client" ? "SERVICE AGREEMENT" : "EMPLOYMENT CONTRACT"}
                    </h2>
                    <p className="text-muted-foreground mt-1">Contract No: {contract.id}</p>
                  </div>

                  {/* Parties */}
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <Building className="h-4 w-4 text-muted-foreground" />
                        <span className="font-medium">Agency</span>
                      </div>
                      <div className="text-muted-foreground">
                        <p>{contract.agencyName}</p>
                        <p className="text-xs">{contract.agencyEmail}</p>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <User className="h-4 w-4 text-muted-foreground" />
                        <span className="font-medium">Client</span>
                      </div>
                      <div className="text-muted-foreground">
                        <p>{contract.clientName}</p>
                        <p className="text-xs">{contract.clientEmail}</p>
                      </div>
                    </div>
                  </div>

                  {/* Project Details */}
                  <div className="space-y-2">
                    <h3 className="font-medium">Project Details</h3>
                    <div className="text-muted-foreground space-y-1">
                      <p>
                        <span className="font-medium">Title:</span> {contract.projectTitle}
                      </p>
                      {contract.projectDescription && (
                        <p>
                          <span className="font-medium">Description:</span> {contract.projectDescription}
                        </p>
                      )}
                      <p>
                        <span className="font-medium">Value:</span> ${contract.paymentAmount?.toLocaleString()}
                      </p>
                      <p>
                        <span className="font-medium">Start Date:</span>{" "}
                        {new Date(contract.startDate).toLocaleDateString()}
                      </p>
                    </div>
                  </div>

                  {/* Scope */}
                  {contract.scope && contract.scope.length > 0 && (
                    <div className="space-y-2">
                      <h3 className="font-medium">Scope of Work</h3>
                      <ul className="text-muted-foreground text-xs space-y-1 list-disc list-inside">
                        {contract.scope.slice(0, 3).map((item: string, index: number) => (
                          <li key={index}>{item}</li>
                        ))}
                        {contract.scope.length > 3 && (
                          <li className="italic">...and {contract.scope.length - 3} more items</li>
                        )}
                      </ul>
                    </div>
                  )}

                  {/* Clauses */}
                  {contract.clauses && contract.clauses.length > 0 && (
                    <div className="space-y-2">
                      <h3 className="font-medium">Key Terms</h3>
                      <div className="text-muted-foreground text-xs space-y-2">
                        {contract.clauses.slice(0, 2).map((clause: any, index: number) => {
                          const safeClause =
                            typeof clause === "object" && clause !== null
                              ? clause
                              : { title: String(clause), description: String(clause) }

                          return (
                            <div key={index} className="border-l-2 border-muted pl-2">
                              <p className="font-medium">{safeClause.title || `Clause ${index + 1}`}</p>
                              <p className="text-xs">
                                {safeClause.description
                                  ? safeClause.description.substring(0, 100) +
                                    (safeClause.description.length > 100 ? "..." : "")
                                  : "No description provided"}
                              </p>
                            </div>
                          )
                        })}
                        {contract.clauses.length > 2 && (
                          <p className="italic">...and {contract.clauses.length - 2} more clauses</p>
                        )}
                      </div>
                    </div>
                  )}

                  {/* Agency Signature */}
                  {contract.agencySignature && (
                    <div className="space-y-2 pt-4 border-t">
                      <h3 className="font-medium flex items-center gap-2">
                        <CheckCircle className="h-4 w-4 text-green-600" />
                        Agency Signature
                      </h3>
                      <div className="bg-green-50 dark:bg-green-950/20 p-3 rounded border">
                        <img
                          src={contract.agencySignature || "/placeholder.svg"}
                          alt="Agency Signature"
                          className="max-w-32 h-8 object-contain"
                        />
                        <p className="text-xs text-green-600 mt-1">
                          Signed on {new Date(contract.agencySignedAt).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Signing Section */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="space-y-6"
          >
            {/* Client Information */}
            <Card className="shadow-lg border-0">
              <CardHeader>
                <CardTitle>Your Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="signer-name">Full Name</Label>
                  <Input
                    id="signer-name"
                    value={signerName}
                    onChange={(e) => setSignerName(e.target.value)}
                    className="transition-all duration-200 focus:ring-2 focus:ring-primary/20"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="signer-email">Email Address</Label>
                  <Input
                    id="signer-email"
                    type="email"
                    value={signerEmail}
                    onChange={(e) => setSignerEmail(e.target.value)}
                    className="transition-all duration-200 focus:ring-2 focus:ring-primary/20"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="signing-date">Signing Date</Label>
                  <Input
                    id="signing-date"
                    type="date"
                    defaultValue={new Date().toISOString().split("T")[0]}
                    className="transition-all duration-200 focus:ring-2 focus:ring-primary/20"
                  />
                </div>
              </CardContent>
            </Card>

            {/* Signature Methods */}
            <Card className="shadow-lg border-0">
              <CardHeader>
                <CardTitle>Digital Signature</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <Button
                    variant={signatureMethod === "draw" ? "default" : "outline"}
                    onClick={() => setSignatureMethod("draw")}
                    className="h-auto p-4 flex-col gap-2 bg-transparent"
                  >
                    <PenTool className="h-6 w-6" />
                    <span className="text-sm">Draw Signature</span>
                  </Button>
                  <Button
                    variant={signatureMethod === "upload" ? "default" : "outline"}
                    onClick={() => setSignatureMethod("upload")}
                    className="h-auto p-4 flex-col gap-2 bg-transparent"
                  >
                    <Upload className="h-6 w-6" />
                    <span className="text-sm">Upload Image</span>
                  </Button>
                </div>

                {signatureMethod === "draw" && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    transition={{ duration: 0.3 }}
                    className="space-y-3"
                  >
                    <div className="border-2 border-dashed border-gray-300 rounded-lg p-4">
                      <canvas
                        ref={canvasRef}
                        width={400}
                        height={120}
                        className="w-full border rounded cursor-crosshair bg-white"
                        onMouseDown={startDrawing}
                        onMouseMove={draw}
                        onMouseUp={stopDrawing}
                        onMouseLeave={stopDrawing}
                      />
                    </div>
                    <Button onClick={clearSignature} variant="outline" size="sm" className="bg-transparent">
                      Clear Signature
                    </Button>
                  </motion.div>
                )}

                {signatureMethod === "upload" && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    transition={{ duration: 0.3 }}
                    className="space-y-3"
                  >
                    <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                      <Upload className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
                      <p className="text-sm text-muted-foreground mb-2">Upload your signature image</p>
                      <Input
                        ref={fileInputRef}
                        type="file"
                        accept="image/*"
                        onChange={handleImageUpload}
                        className="max-w-xs mx-auto"
                      />
                    </div>
                  </motion.div>
                )}
              </CardContent>
            </Card>

            {/* Agreement and Sign */}
            <Card className="shadow-lg border-0">
              <CardContent className="pt-6">
                <div className="space-y-4">
                  <div className="flex items-start space-x-2">
                    <input type="checkbox" id="agreement" className="mt-1" />
                    <Label htmlFor="agreement" className="text-sm leading-relaxed">
                      I have read and agree to the terms and conditions outlined in this contract. I understand that
                      this digital signature is legally binding and equivalent to a handwritten signature.
                    </Label>
                  </div>
                  <div className="flex gap-3">
                    <Button onClick={handleDownload} variant="outline" className="flex-1 bg-transparent">
                      <Download className="mr-2 h-4 w-4" />
                      Download
                    </Button>
                    <Button
                      onClick={handleSignContract}
                      disabled={!signatureMethod || !signerName || !signerEmail}
                      className="flex-1 shadow-lg hover:shadow-xl transition-shadow"
                    >
                      <PenTool className="mr-2 h-4 w-4" />
                      Sign Contract
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>

      {/* Footer Branding */}
      <footer className="bg-white dark:bg-gray-800 border-t mt-12">
        <div className="container mx-auto px-6 py-4">
          <div className="text-center">
            <p className="text-xs text-muted-foreground">
              Product by <span className="font-semibold text-primary">Drimin AI</span>
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}
